import 'dart:io';
import 'package:flutter/services.dart';
import 'package:mw/models/member_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DbHelper {
  static Database _db;
  static const String MID = 'mid';
  static const String MEMBERSHIPDATE = 'membershipdate';
  static const String FULLNAME = 'fullname';
  static const String DOB = 'dob';
  static const String BARANGAY = 'barangay';
  static const String STATUS = 'status';
  static const String TABLE = 'tblmembers';
  static const String DBNAME = 'db.db3';

  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await _initDb();
    return _db;
  }

/*
  _initDbOverWrite() async {

    var databasesPath = await getDatabasesPath();
    var path = join(databasesPath, "db.db3");

// delete existing if any
    await deleteDatabase(path);

// Make sure the parent directory exists
    try {
      await Directory(dirname(path)).create(recursive: true);
    } catch (_) {}

// Copy from asset
    ByteData data = await rootBundle.load(join("assets/database", "db.db3"));
    List<int> bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await new File(path).writeAsBytes(bytes, flush: true);

// open the database
    var db = await openDatabase(path, readOnly: true);
    return db;
  }
*/

  _initDb() async {
    var databasesPath = await getDatabasesPath();
    var path = join(databasesPath, "db.db3");
    // Check if the database exists
    var exists = await databaseExists(path);

    if (!exists) {
      // Should happen only the first time you launch your application
      print("Creating new copy from asset");

      // Make sure the parent directory exists
      try {
        await Directory(dirname(path)).create(recursive: true);
      } catch (_) {}

      // Copy from asset
      ByteData data = await rootBundle.load(join("assets/database", "db.db3"));
      List<int> bytes =
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

      // Write and flush the bytes written
      await File(path).writeAsBytes(bytes, flush: true);
    } else {
      print("Opening existing database");
    }
// open the database
    var db = await openDatabase(path, readOnly: true);
    return db;
  }

  Future<List<Member>> getMembers() async {
    var dBClient = await db;
    List<Map> maps = await dBClient.rawQuery(
        "SELECT mid, membershipdate, lastname || ', ' || firstname || ' ' || CASE mi WHEN '' THEN '' ELSE mi || '.' END AS fullname, dob, barangay, CASE WHEN DATE(substr(membershipdate,7,4)||'-'||substr(membershipdate,1,2)||'-'||substr(membershipdate,4,2), '+1 year') <= date('now','start of month','+1 month','-1 day') THEN 'EXPIRED' ELSE 'ACTIVE' END AS status FROM tblmembers");
    List<Member> members = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        members.add(Member.fromMap(maps[i]));
      }
    }
    return members;
  }

  Future<List<Member>> search(String keyword,
      [String filterBarangay = '', String filterStatus = '']) async {
    var dBClient = await db;
    List<Map> maps = await dBClient.rawQuery(
        "SELECT mid, membershipdate, lastname || ', ' || firstname || ' ' || CASE mi WHEN '' THEN '' ELSE mi || '.' END AS fullname, dob, barangay, CASE WHEN DATE(substr(membershipdate,7,4)||'-'||substr(membershipdate,1,2)||'-'||substr(membershipdate,4,2), '+1 year') <= date('now','start of month','+1 month','-1 day') THEN 'EXPIRED' ELSE 'ACTIVE' END AS status FROM tblmembers WHERE fullname LIKE '%$keyword%' $filterBarangay $filterStatus");
    List<Member> members = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        members.add(Member.fromMap(maps[i]));
      }
    }
    return members;
  }

  Future<List<Member>> birthday() async {
    var dBClient = await db;
    List<Map> maps = await dBClient.rawQuery(
        "SELECT mid, membershipdate, lastname || ', ' || firstname || ' ' || CASE mi WHEN '' THEN '' ELSE mi || '.' END AS fullname, dob, barangay, CASE WHEN DATE(substr(membershipdate,7,4)||'-'||substr(membershipdate,1,2)||'-'||substr(membershipdate,4,2), '+1 year') <= date('now','start of month','+1 month','-1 day') THEN 'EXPIRED' ELSE 'ACTIVE' END AS status FROM tblmembers WHERE substr(strftime('%Y-%m-%d',datetime(substr(dob, 7, 4) || '-' || substr(dob, 1, 2) || '-' || substr(dob, 4, 2))), 6, 5) = strftime('%m-%d',date('now', 'localtime'))");
    List<Member> members = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        members.add(Member.fromMap(maps[i]));
      }
    }
    return members;
  }
}
