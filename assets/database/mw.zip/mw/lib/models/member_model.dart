class Member {

  String mid;
  String membershipdate;
  String fullname;
  String dob;
  String barangay;
  String status;

  Member({this.mid, this.membershipdate, this.fullname, this.dob, this.barangay, this.status});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'mid' : mid,
      'membershipdate' : membershipdate,
      'fullname' : fullname,
      'dob' : dob,
      'barangay' : barangay,
      'status' : status
    };
    return map;
  }

  Member.fromMap(Map<String, dynamic> map) {
    mid = map['mid'];
    membershipdate = map['membershipdate'];
    fullname = map['fullname'];
    dob = map['dob'];
    barangay = map['barangay'];
    status = map['status'];
  }
}